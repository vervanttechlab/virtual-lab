-- Day 5 SQL queries · Name: ____________________  Date: __________
-- Type each answer query on the empty line under its question. End every query with a semicolon ;
-- How to run one query: select (highlight) it, then press Ctrl+E, Ctrl+E
-- (or click 'Run on active connection' just above it).

-- Q1 (Activity 5.1). How many sales (rows) are in the sales table? Name the column total_sales.


-- Q2 (Activity 5.1). What is the total revenue (sum of total_amount)? Name it total_revenue.


-- Q3 (Activity 5.1). What is the average sale amount, rounded to 2 decimals? Name it avg_sale.


-- Q4 (Activity 5.1). How much revenue came from GCash sales? Name it gcash_revenue.


-- Q5 (Activity 5.1). What are the cheapest and the most expensive unit prices in the products table? Name them lowest_price and highest_price.


-- Q6 (Activity 5.1). How many different suki customers bought something? Name it buying_customers.


-- Q7 (Activity 5.1). How many sales were walk-in sales (no customer ID)? Name it walk_in_sales.


-- Q8 (Activity 5.2). Show every sale with its product name: sale_id, sale_date, product_name, quantity, total_amount.


-- Q9 (Activity 5.2). What is the total revenue of the Beverages category? Name it beverages_revenue.


-- Q10 (Activity 5.2). Show the sale ID, branch name and total amount of every sale made in Marikina.


-- Q11 (Activity 5.3). Build the joined dataset: sale_id, sale_date, branch_name, product_name, category, quantity, unit_price, total_amount, payment_method, ordered by sale_id.


-- Q12 (Activity 5.4). Which products have never been sold? Show product_id and product_name.


-- Q13 (Activity 5.4). Which branch has no sales yet? Show branch_id, branch_name and status.


-- Q14 (Activity 5.4). Which suki customers have never bought anything? Show customer_id, first_name, last_name, joined_on.
