-- Day 4 SQL queries · Name: ____________________  Date: __________
-- Type each answer query on the empty line under its question. End every query with a semicolon ;
-- How to run one query: select (highlight) it, then press Ctrl+E, Ctrl+E
-- (or click 'Run on active connection' just above it).

-- Q1 (Activity 4.2). Show every column of every branch.


-- Q2 (Activity 4.2). Show only the product name, category and unit price of every product.


-- Q3 (Activity 4.2). Show the first name, last name and city of every customer.


-- Q4 (Activity 4.2). List each product category once (no repeats).


-- Q5 (Activity 4.3). Show the name and price of all products in the Beverages category.


-- Q6 (Activity 4.3). Show the name and price of products that cost more than 60 pesos.


-- Q7 (Activity 4.3). Show the sale ID, date and total amount of Pasig (BR03) sales paid with GCash.


-- Q8 (Activity 4.3). Show the sale ID, date and total amount of sales from 1 to 7 February 2026.


-- Q9 (Activity 4.3). Show the name and price of every product with the word Milk in its name.


-- Q10 (Activity 4.3). Show the ID, first name and last name of customers who have no email address.


-- Q11 (Activity 4.3). Show the sale ID, payment method and quantity of e-wallet sales (GCash or Maya) with a quantity of 3 or more.


-- Q12 (Activity 4.4). Show the 5 most expensive products (name and price), most expensive first.


-- Q13 (Activity 4.4). Show the 10 biggest sales (sale ID, branch ID, total amount), biggest first. If two sales tie, the smaller sale ID comes first.


-- Q14 (Activity 4.4). List each payment method used in the sales table once, in A to Z order.


-- Q15 (Activity 4.4). Show the sale ID, time and total amount of all Valentine's Day sales (14 February 2026), earliest first.
